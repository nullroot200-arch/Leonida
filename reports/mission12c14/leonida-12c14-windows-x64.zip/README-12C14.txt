LEONIDA 12C.14 - Windows x64 validation package

This package is synthetic infrastructure. It contains no GTA 6 executable, RPF, TTPF,
shader, asset, credential, key or licence material. The runtime must not be started with
--init or --run. No file in this package proves GTA 6 compatibility.

Contents
  gta6rt.exe                   runtime build from 12C.13 (cross-compiled, unchanged)
  gta6rt_tls_host.dll         TLS anchor loaded next to the EXE
  test_pe_loader_bounds.exe   synthetic PE-loader regression
  import_export_bench.exe     synthetic CPU benchmark
  d3d12_probe.exe             standalone D3D12 WARP/hardware diagnostic
  mission12c14-release-manifest.json
  SHA256SUMS

Prerequisites on Windows 11 x64
  * Microsoft Visual C++ 2015-2022 Redistributable (x64): MSVCP140.dll,
    VCRUNTIME140.dll and VCRUNTIME140_1.dll. They are not bundled.
  * Windows 11 inbox DXGI and D3D12. The probe reports missing components; it does not install them.
  * Vulkan is optional for this package. A Vulkan loader or ICD alone is not a GPU PASS.

Read-only package check (from the repository root)
  powershell -NoProfile -ExecutionPolicy Bypass -File tools\leonida-verify\windows\verify_package.ps1 `
    -Manifest reports\mission12c14\windows-x64\mission12c14-release-manifest.json `
    -PackageDir reports\mission12c14\windows-x64 `
    -OutDir C:\leonida-reports\12c14

Environment collection
  powershell -NoProfile -ExecutionPolicy Bypass -File tools\leonida-verify\windows\collect_environment.ps1 `
    -OutDir C:\leonida-reports\12c14

D3D12 diagnostic, separate labels
  .\d3d12_probe.exe --warp
  .\d3d12_probe.exe --hardware
  .\d3d12_probe.exe --debug --hardware

Interpretation
  D3D12_WARP_PASS       WARP device, queue, allocator, list and fence completed; SOFTWARE, not a GPU
  D3D12_HARDWARE_PASS   hardware adapter (DXGI_ADAPTER_FLAG_SOFTWARE clear), device and fence completed
  NOT_AVAILABLE         requested adapter/runtime unavailable; record BLOCKED, do not relabel as PASS
  FAIL                  a concrete HRESULT or fence timeout; preserve the full output

The probe selects an NVIDIA adapter when one is present, otherwise the first hardware adapter. It never
loads a game image. A device creation result is not a shader, swapchain, presentation or GTA 6 result.

CPU tests and benchmark
  .\test_pe_loader_bounds.exe
  .\import_export_bench.exe C:\temp\leonida-bench

Native harness (from the repository root; review the script before running)
  powershell -NoProfile -ExecutionPolicy Bypass -File tools\leonida-verify\windows\run_validation.ps1 `
    -BuildDir C:\leonida-build-12c14 -OutDir C:\leonida-reports\12c14 -RunD3D12Probe `
    -PackageManifest reports\mission12c14\windows-x64\mission12c14-release-manifest.json `
    -PackageDir reports\mission12c14\windows-x64

The harness excludes ^run_ and ^gta6rt_rejects_ and inspects every selected CTest command line for
--run/--init. It must not be changed to make a failing test disappear.

Return these files for the next mission
  environment.json, environment.txt, configure.log, build.log, ctest-list.txt,
  ctest-list-verbose.txt, ctest.log, d3d12-warp.log, d3d12-hardware.log,
  package-verification.json, validation.json and their .sha256 sidecars.
